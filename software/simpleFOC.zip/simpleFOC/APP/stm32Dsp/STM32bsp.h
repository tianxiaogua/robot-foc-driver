#ifndef STM32bsp_H
#define STM32bsp_H

#include "main.h"
#include "stdio.h"

#include "adc.h"
#include "can.h"
#include "dma.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"


extern float rad_speed;
extern uint8_t time_flag_2ms;
extern uint8_t time_flag_20ms;
extern uint8_t time_flag_100ms;

#define TimeFlagMaskT10ms  ((uint32_t)0xf<<0)
#define TimeFlagMaskT50ms  ((uint32_t)0xf<<4)
#define TimeFlagMaskT100ms ((uint32_t)0xf<<8)
#define TimeFlagMaskT200ms ((uint32_t)0xf<<12)
#define TimeFlagMaskT500ms ((uint32_t)0xf<<16)
#define TimeFlagMaskT1s    ((uint32_t)0xf<<20)
#pragma anon_unions // keil��������!!!!!!!!!!!!!!!!!!!!!!!!
union SYSTimeStrctUnion
{
  uint32_t flag;
  struct
  {
    uint32_t :1;        // 10ms
    uint32_t :1;
    uint32_t :1;
    uint32_t T10ms:1;

    uint32_t T50ms:1;   // 50ms
    uint32_t mot_50ms:1;
    uint32_t :1;        //
    uint32_t :1;

    uint32_t T100ms:1;    //100ms    
    uint32_t mot_100ms:1;
    uint32_t :1;
    uint32_t :1;
    
    uint32_t T200ms:1;    //200ms    
    uint32_t T200ms_1:1;
    uint32_t mot_200ms:1;
    uint32_t :1;

    uint32_t T500ms_1:1;    // 500ms
    uint32_t mot_500ms:1;
    uint32_t :1;
    uint32_t T500ms:1;

    uint32_t mot_1s:1;      // 1s
    uint32_t T1s_1:1; //
    uint32_t T1s_2:1;
    uint32_t T1s_3:1;

    uint32_t :8;
  };
};

// ��ʱ������ ////////////////////////////////////////////////////////////////////////////////////////////////////
#define TIM_HandleTypeDef_HTMI htim4
/*******************************************************************************
 * @file   : motor_control.c
 * @brief  : ���ж�
 * @author : TianHao
 * @date   : 2023-12
 ******************************************************************************/
void init_interrupt(void);

/*******************************************************************************
 * @file   motor_control.c
 * @brief  ����PWMռ�ձ�
 * @author Tianxiaogua
 * @date   2023-04
 ******************************************************************************/
uint32_t set_pwm(TIM_HandleTypeDef *htim, uint32_t Channel, int32_t tim);


void bsp_init(void);

#endif

