#include "STM32bsp.h"
#include "as5600.h"
#include "MyProject.h"

/*******************************************************************************
 * @file   : motor_control.c
 * @brief  : ���ж�
 * @author : TianHao
 * @date   : 2023-12
 ******************************************************************************/
void init_interrupt(void)
{
	HAL_TIM_Base_Start_IT(&TIM_HandleTypeDef_HTMI);       //ͨ�����д��룬���жϵķ�ʽ������ʱ����  
}

float rad_speed;
/*******************************************************************************
 * @file   : motor_control.c
 * @brief  : ���ö�ʱ�����ж�2msһ�Σ���ʱ���жϺ��� ��50ms 20Hzһ�ε��ж��� ͨ�������ķ�ʽ��Ƶ��50��100��200��500ms
��ʱʱ�䣺 Time = (ARR+1) * (PSC+1) / Tclk = ����װ��ֵ+1����Ԥ��Ƶϵ��+1��/ ʱ��Ƶ�� = ��7199+1�� ��9999+1��/ 72 000 000 = 1s
 * @author : LiChuan
 * @date   : 2023-04
 ******************************************************************************/
union SYSTimeStrctUnion Time_Flag;
uint8_t time_flag_2ms;
uint8_t time_flag_20ms;
uint8_t time_flag_100ms;

uint32_t  tim_tick;   // ϵͳ����tick
uint32_t   tim_cnt_100ms=0;    // 10ms���ڼ�����
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{  
#define ms 2
#if ms==2
  if(htim == &TIM_HandleTypeDef_HTMI)  //�ж��ж��Ƿ������ڶ�ʱ��4
	{
    time_flag_2ms = 1;
		tim_cnt_100ms++;
    if(tim_cnt_100ms >= 50) { // 100ms�ж�
      tim_cnt_100ms = 0;
      time_flag_100ms = 1;
    }
    move(6.28);
    loopFOC();
	}
#endif
	
#if ms==10
	if(htim == &TIM_HandleTypeDef_HTMI)  //�ж��ж��Ƿ������ڶ�ʱ��4
	{
	  tim_tick++;
    tim_cnt++;
    Time_Flag.flag |= TimeFlagMaskT10ms;
    if((tim_cnt % 5)==0) // 50ms
    {
      Time_Flag.flag |= TimeFlagMaskT50ms;
      if((tim_cnt % 10)==0)
      {
        Time_Flag.flag |= TimeFlagMaskT100ms;

        if((tim_cnt % 20)==0)
        {
          Time_Flag.flag |= TimeFlagMaskT200ms;
        }
        
        if((tim_cnt % 50)==0)
        {
          Time_Flag.flag |= TimeFlagMaskT500ms;
					printf("%f \r\n", bsp_as5600GetAngle() );
        }
      }
    }
    if(tim_cnt >= 100)
    {
      Time_Flag.flag |= TimeFlagMaskT1s;
      tim_cnt = 0;
    }
	}
#endif
}

/*****************************************************************************
 * @file   motor_control.c
 * @brief  ��ʼ������DMA
 * @author Tianxiaogua
 * @date   2023-04
 ****************************************************************************/
void init_usart()
{
//	HAL_UART_Receive_DMA(&huart1, Rx_Buf, Rx_Max);  
//	__HAL_UART_ENABLE_IT(&huart1, UART_IT_IDLE); 
//	HAL_UART_Receive_DMA(&huart2, Rx2_Buf, Rx_Max);  
//	__HAL_UART_ENABLE_IT(&huart2, UART_IT_IDLE); 
//  HAL_UART_Receive_DMA(&huart3, Rx3_Buf, Rx_Max);  
//	__HAL_UART_ENABLE_IT(&huart3, UART_IT_IDLE); 
//  HAL_UART_Receive_DMA(&huart4, Rx4_Buf, Rx_Max);  
//	__HAL_UART_ENABLE_IT(&huart4, UART_IT_IDLE); 
}

/*******************************************************************************
 * @file   motor_control.c
 * @brief  ��ʼ��PWM���� PWMƵ�����ã�168000000��168��1000 = 1000 Hz 
 * @author Tianxiaogua
 * @date   2023-04
 ******************************************************************************/
void init_PWM()
{
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1); 
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 0); 
	
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2); 
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, 0);    //�޸�ռ�ձ�
	
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_3); 
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3, 0);    //�޸�ռ�ձ�
}



/*******************************************************************************
 * @file   motor_control.c
 * @brief  ����PWMռ�ձ�
 * @author Tianxiaogua
 * @date   2023-04
 ******************************************************************************/
uint32_t set_pwm(TIM_HandleTypeDef *htim, uint32_t Channel, int32_t tim)
{
	return __HAL_TIM_SET_COMPARE(htim,Channel, tim);
}


/*******************************************************************************
 * @file   : motor_control.c
 * @brief  : ��ʼ��ETR �ⲿ��������� 
 * @author : Tianxiaogua
 * @date   : 2023-04
 ******************************************************************************/
void init_ETR()
{
//	HAL_TIM_Base_Start(&htim2); // �ⲿ�������� ETR
//	HAL_TIM_Base_Start(&htim4); // �ⲿ�������� ETR
}


/*******************************************************************************
 * @file   : motor_control.c
 * @brief  : ��ȡ���ֵ�������
 * @author : LiChuan
 * @date   : 2023-04
 ******************************************************************************/
static  uint32_t left_tick = 0;
static  uint32_t right_tick = 0;
#define __HAL_TIM_GET_COUNTER_htim htim1
uint32_t get_wheel_left(void)
{
	uint32_t ETRCount;
  uint32_t t_cnt;
	ETRCount = __HAL_TIM_GET_COUNTER(&__HAL_TIM_GET_COUNTER_htim);//��ȡ��ʱ��2�ļ���ֵ
  if(ETRCount >= left_tick)
  {
    t_cnt = ETRCount - left_tick;
  }
  else
  {
    t_cnt = 0x10000 + ETRCount - left_tick;
  }
  left_tick = ETRCount;
  return t_cnt;
}



/*******************************************************************************
 * @file   : motor_control.c
 * @brief  : ��ȡ���ֵ�������
 * @author : LiChuan
 * @date   : 2023-04
 ******************************************************************************/
uint32_t get_wheel_right(void)
{
  uint32_t ETRCount;
  uint32_t t_cnt;
  ETRCount = __HAL_TIM_GET_COUNTER(&__HAL_TIM_GET_COUNTER_htim);//��ȡ��ʱ��3�ļ���ֵ
  if(ETRCount >= right_tick)
  {
    t_cnt = ETRCount - right_tick;
  }
  else
  {
    t_cnt = 0x10000 + ETRCount - right_tick;
  }
  right_tick = ETRCount;
  return t_cnt;
}


/*******************************************************************************
 * @file   : motor_control.c
 * @brief  : �ٶȲɼ�
 * @author : Tianxiaogua
 * @date   : 2023-06
 ******************************************************************************/
void speed_collecting(void)
{
//  uint16_t ETRCountL = 0; 
//	uint16_t ETRCountR = 0;

//  ETRCountL = get_wheel_left();  // ��ȡ��ʱ��2�ļ���ֵ
//  ETRCountR = get_wheel_right(); // ��ȡ��ʱ��3�ļ���ֵ
//  update_mot_data(&mot_left, ETRCountL); //  �����������ӵ������ٶ�
//  update_mot_data(&mot_right, ETRCountR);
}



void bsp_init(void)
{
	
	init_PWM();
}
