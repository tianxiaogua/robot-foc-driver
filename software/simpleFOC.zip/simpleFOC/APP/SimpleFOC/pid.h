#ifndef PID_H
#define PID_H

extern float sum_error;
/******************************************************************************/
void PID_init(void);
float PID_velocity(float error);
float PID_angle(float error);
/******************************************************************************/
float pid(float target_value, float feedback_value) ;
#endif

