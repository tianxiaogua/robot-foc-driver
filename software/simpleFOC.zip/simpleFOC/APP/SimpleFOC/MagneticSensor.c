

#include "MyProject.h"
#include "as5600.h"
#include "STM32bsp.h"
#include "kalman.h"
/************************************************
本程序仅供学习，引用代码请标明出处
使用教程：https://blog.csdn.net/loop222/article/details/120471390
创建日期：20210925
作    者：loop222 @郑州
************************************************/
/******************************************************************************/
long  cpr;
float full_rotation_offset;
long  angle_data_prev;
unsigned long velocity_calc_timestamp;
float angle_prev;
/******************************************************************************/
#define  AS5600_Address  0x36
#define  RAW_Angle_Hi    0x0C   //V2.1.1 bugfix
//#define  RAW_Angle_Lo    0x0D
#define  AS5600_CPR      4096

/******************************************************************************/
void MagneticSensor_Init(void)
{
	cpr = AS5600_CPR;
	full_rotation_offset = 0;
	velocity_calc_timestamp=0;
}
/******************************************************************************/
float getAngle(void)
{
//	float angle_data,d_angle;
//	
//	angle_data = bsp_as5600GetRawAngle(); // 获取原始角度

//	
//	// tracking the number of rotations 
//	// in order to expand angle range form [0,2PI] to basically infinity
//	d_angle = angle_data - angle_data_prev;
//	// if overflow happened track it as full rotation
//	if(fabs(d_angle) > (0.8*cpr) ) full_rotation_offset += d_angle > 0 ? -_2PI : _2PI; 
//	// save the current angle value for the next steps
//	// in order to know if overflow happened
//	angle_data_prev = angle_data;
//	// return the full angle 
//	// (number of full rotations)*2PI + current sensor angle 
//	return  (full_rotation_offset + ( angle_data / (float)cpr) * _2PI) ;
	return bsp_as5600GetAngle(); // 获取弧度制角度
}
/******************************************************************************/
// Shaft velocity calculation
float getVelocity(void)
{
	// unsigned long now_us;
	// float Ts, angle_c, vel;

	// // calculate sample time
	// now_us = SysTick->VAL; //_micros();
	// if(now_us<velocity_calc_timestamp)Ts = (float)(velocity_calc_timestamp - now_us)/9*1e-6;
	// else
	// 	Ts = (float)(0xFFFFFF - now_us + velocity_calc_timestamp)/9*1e-6;
	// // quick fix for strange cases (micros overflow)
	// if(Ts == 0 || Ts > 0.5) Ts = 1e-3;

	// // current angle
	// angle_c = getAngle();
	// // velocity calculation
	// vel = (angle_c - angle_prev)/Ts;

	// // save variables for future pass
	// angle_prev = angle_c;
	// velocity_calc_timestamp = now_us;
	rad_speed = count_shaft_speed();
	rad_speed = KalmanFilter(&kfp, rad_speed);
	return rad_speed;
}
/******************************************************************************/



