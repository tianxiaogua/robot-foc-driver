#ifndef FOC_H
#define FOC_H
#include "STM32bsp.h"
#include "MyProject.h"

void test(void);

#endif

